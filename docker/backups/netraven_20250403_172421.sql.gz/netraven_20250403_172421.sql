--
-- PostgreSQL database dump
--

-- Dumped from database version 14.17
-- Dumped by pg_dump version 14.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: netraven; Type: SCHEMA; Schema: -; Owner: netraven
--

CREATE SCHEMA netraven;


ALTER SCHEMA netraven OWNER TO netraven;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_settings; Type: TABLE; Schema: netraven; Owner: netraven
--

CREATE TABLE netraven.admin_settings (
    id uuid NOT NULL,
    key character varying NOT NULL,
    value json,
    value_type character varying NOT NULL,
    category character varying NOT NULL,
    description text,
    is_required boolean,
    is_sensitive boolean,
    display_order integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE netraven.admin_settings OWNER TO netraven;

--
-- Name: COLUMN admin_settings.value_type; Type: COMMENT; Schema: netraven; Owner: netraven
--

COMMENT ON COLUMN netraven.admin_settings.value_type IS 'Type of value (string, number, boolean, json)';


--
-- Name: COLUMN admin_settings.category; Type: COMMENT; Schema: netraven; Owner: netraven
--

COMMENT ON COLUMN netraven.admin_settings.category IS 'Category of setting (security, system, notification)';


--
-- Name: audit_logs; Type: TABLE; Schema: netraven; Owner: netraven
--

CREATE TABLE netraven.audit_logs (
    id uuid NOT NULL,
    event_type character varying(32) NOT NULL,
    event_name character varying(64) NOT NULL,
    actor_id character varying(255),
    actor_type character varying(32),
    target_id character varying(255),
    target_type character varying(32),
    ip_address character varying(45),
    user_agent text,
    session_id character varying(64),
    description text NOT NULL,
    status character varying(16) NOT NULL,
    event_metadata json,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE netraven.audit_logs OWNER TO netraven;

--
-- Name: COLUMN audit_logs.event_type; Type: COMMENT; Schema: netraven; Owner: netraven
--

COMMENT ON COLUMN netraven.audit_logs.event_type IS 'Type of event (auth, admin, key, data)';


--
-- Name: COLUMN audit_logs.event_name; Type: COMMENT; Schema: netraven; Owner: netraven
--

COMMENT ON COLUMN netraven.audit_logs.event_name IS 'Specific event name (login, update, etc.)';


--
-- Name: COLUMN audit_logs.actor_id; Type: COMMENT; Schema: netraven; Owner: netraven
--

COMMENT ON COLUMN netraven.audit_logs.actor_id IS 'ID of the user or system component that initiated the action';


--
-- Name: COLUMN audit_logs.actor_type; Type: COMMENT; Schema: netraven; Owner: netraven
--

COMMENT ON COLUMN netraven.audit_logs.actor_type IS 'Type of actor (user, system, service)';


--
-- Name: COLUMN audit_logs.target_id; Type: COMMENT; Schema: netraven; Owner: netraven
--

COMMENT ON COLUMN netraven.audit_logs.target_id IS 'ID of the resource being acted upon';


--
-- Name: COLUMN audit_logs.target_type; Type: COMMENT; Schema: netraven; Owner: netraven
--

COMMENT ON COLUMN netraven.audit_logs.target_type IS 'Type of target resource (user, device, backup, etc.)';


--
-- Name: COLUMN audit_logs.ip_address; Type: COMMENT; Schema: netraven; Owner: netraven
--

COMMENT ON COLUMN netraven.audit_logs.ip_address IS 'IP address of the client';


--
-- Name: COLUMN audit_logs.user_agent; Type: COMMENT; Schema: netraven; Owner: netraven
--

COMMENT ON COLUMN netraven.audit_logs.user_agent IS 'User agent of the client';


--
-- Name: COLUMN audit_logs.session_id; Type: COMMENT; Schema: netraven; Owner: netraven
--

COMMENT ON COLUMN netraven.audit_logs.session_id IS 'Session ID for the request';


--
-- Name: COLUMN audit_logs.description; Type: COMMENT; Schema: netraven; Owner: netraven
--

COMMENT ON COLUMN netraven.audit_logs.description IS 'Human-readable description of the event';


--
-- Name: COLUMN audit_logs.status; Type: COMMENT; Schema: netraven; Owner: netraven
--

COMMENT ON COLUMN netraven.audit_logs.status IS 'Outcome status (success, failure, error, warning)';


--
-- Name: COLUMN audit_logs.event_metadata; Type: COMMENT; Schema: netraven; Owner: netraven
--

COMMENT ON COLUMN netraven.audit_logs.event_metadata IS 'Additional structured data about the event';


--
-- Name: COLUMN audit_logs.created_at; Type: COMMENT; Schema: netraven; Owner: netraven
--

COMMENT ON COLUMN netraven.audit_logs.created_at IS 'Timestamp when the event was logged';


--
-- Name: backups; Type: TABLE; Schema: netraven; Owner: netraven
--

CREATE TABLE netraven.backups (
    id character varying(36) NOT NULL,
    version character varying(20) NOT NULL,
    file_path character varying(512) NOT NULL,
    file_size integer NOT NULL,
    status character varying(20) NOT NULL,
    comment text,
    content_hash character varying(128),
    is_automatic boolean,
    created_at timestamp without time zone,
    serial_number character varying(50),
    device_id character varying(36) NOT NULL
);


ALTER TABLE netraven.backups OWNER TO netraven;

--
-- Name: credential_tags; Type: TABLE; Schema: netraven; Owner: netraven
--

CREATE TABLE netraven.credential_tags (
    id character varying(36) NOT NULL,
    credential_id character varying(36) NOT NULL,
    tag_id character varying(36) NOT NULL,
    priority double precision,
    success_count integer,
    failure_count integer,
    last_used timestamp without time zone,
    last_success timestamp without time zone,
    last_failure timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE netraven.credential_tags OWNER TO netraven;

--
-- Name: credentials; Type: TABLE; Schema: netraven; Owner: netraven
--

CREATE TABLE netraven.credentials (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    username character varying(255) NOT NULL,
    password character varying(1024),
    use_keys boolean,
    key_file character varying(1024),
    success_count integer,
    failure_count integer,
    last_used timestamp without time zone,
    last_success timestamp without time zone,
    last_failure timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE netraven.credentials OWNER TO netraven;

--
-- Name: device_tags; Type: TABLE; Schema: netraven; Owner: netraven
--

CREATE TABLE netraven.device_tags (
    device_id character varying(36) NOT NULL,
    tag_id character varying(36) NOT NULL,
    created_at timestamp without time zone
);


ALTER TABLE netraven.device_tags OWNER TO netraven;

--
-- Name: devices; Type: TABLE; Schema: netraven; Owner: netraven
--

CREATE TABLE netraven.devices (
    id character varying(36) NOT NULL,
    hostname character varying(255) NOT NULL,
    ip_address character varying(45) NOT NULL,
    device_type character varying(50) NOT NULL,
    port integer,
    username character varying(64),
    password character varying(128),
    description text,
    last_backup_at timestamp without time zone,
    last_backup_status character varying(20),
    enabled boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    serial_number character varying(100),
    is_reachable boolean,
    last_reachability_check timestamp without time zone,
    owner_id character varying(36) NOT NULL
);


ALTER TABLE netraven.devices OWNER TO netraven;

--
-- Name: job_log_entries; Type: TABLE; Schema: netraven; Owner: netraven
--

CREATE TABLE netraven.job_log_entries (
    id character varying(36) NOT NULL,
    job_log_id character varying(36) NOT NULL,
    "timestamp" timestamp without time zone NOT NULL,
    level character varying(20) NOT NULL,
    category character varying(50),
    message text NOT NULL,
    details json,
    session_log_path character varying(255),
    session_log_content text,
    credential_username character varying(255)
);


ALTER TABLE netraven.job_log_entries OWNER TO netraven;

--
-- Name: job_logs; Type: TABLE; Schema: netraven; Owner: netraven
--

CREATE TABLE netraven.job_logs (
    id character varying(36) NOT NULL,
    session_id character varying(36) NOT NULL,
    job_type character varying(50) NOT NULL,
    status character varying(20) NOT NULL,
    start_time timestamp without time zone NOT NULL,
    end_time timestamp without time zone,
    result_message text,
    job_data jsonb,
    retention_days integer,
    device_id character varying(36),
    created_by character varying(36) NOT NULL
);


ALTER TABLE netraven.job_logs OWNER TO netraven;

--
-- Name: scheduled_jobs; Type: TABLE; Schema: netraven; Owner: netraven
--

CREATE TABLE netraven.scheduled_jobs (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    device_id character varying(36) NOT NULL,
    schedule_type character varying(50) NOT NULL,
    schedule_time character varying(5),
    schedule_interval integer,
    schedule_day character varying(10),
    enabled boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    last_run timestamp without time zone,
    next_run timestamp without time zone,
    created_by character varying(36) NOT NULL,
    job_data json
);


ALTER TABLE netraven.scheduled_jobs OWNER TO netraven;

--
-- Name: tag_rules; Type: TABLE; Schema: netraven; Owner: netraven
--

CREATE TABLE netraven.tag_rules (
    id character varying(36) NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    rule_criteria text NOT NULL,
    is_active boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    tag_id character varying(36) NOT NULL
);


ALTER TABLE netraven.tag_rules OWNER TO netraven;

--
-- Name: tags; Type: TABLE; Schema: netraven; Owner: netraven
--

CREATE TABLE netraven.tags (
    id character varying(36) NOT NULL,
    name character varying(50) NOT NULL,
    description text,
    color character varying(7),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE netraven.tags OWNER TO netraven;

--
-- Name: users; Type: TABLE; Schema: netraven; Owner: netraven
--

CREATE TABLE netraven.users (
    id character varying(36) NOT NULL,
    username character varying(50) NOT NULL,
    email character varying(100) NOT NULL,
    full_name character varying(120),
    password_hash character varying(100) NOT NULL,
    is_active boolean,
    is_admin boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    notification_preferences jsonb
);


ALTER TABLE netraven.users OWNER TO netraven;

--
-- Data for Name: admin_settings; Type: TABLE DATA; Schema: netraven; Owner: netraven
--

COPY netraven.admin_settings (id, key, value, value_type, category, description, is_required, is_sensitive, display_order, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: netraven; Owner: netraven
--

COPY netraven.audit_logs (id, event_type, event_name, actor_id, actor_type, target_id, target_type, ip_address, user_agent, session_id, description, status, event_metadata, created_at) FROM stdin;
\.


--
-- Data for Name: backups; Type: TABLE DATA; Schema: netraven; Owner: netraven
--

COPY netraven.backups (id, version, file_path, file_size, status, comment, content_hash, is_automatic, created_at, serial_number, device_id) FROM stdin;
\.


--
-- Data for Name: credential_tags; Type: TABLE DATA; Schema: netraven; Owner: netraven
--

COPY netraven.credential_tags (id, credential_id, tag_id, priority, success_count, failure_count, last_used, last_success, last_failure, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: credentials; Type: TABLE DATA; Schema: netraven; Owner: netraven
--

COPY netraven.credentials (id, name, description, username, password, use_keys, key_file, success_count, failure_count, last_used, last_success, last_failure, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: device_tags; Type: TABLE DATA; Schema: netraven; Owner: netraven
--

COPY netraven.device_tags (device_id, tag_id, created_at) FROM stdin;
\.


--
-- Data for Name: devices; Type: TABLE DATA; Schema: netraven; Owner: netraven
--

COPY netraven.devices (id, hostname, ip_address, device_type, port, username, password, description, last_backup_at, last_backup_status, enabled, created_at, updated_at, serial_number, is_reachable, last_reachability_check, owner_id) FROM stdin;
\.


--
-- Data for Name: job_log_entries; Type: TABLE DATA; Schema: netraven; Owner: netraven
--

COPY netraven.job_log_entries (id, job_log_id, "timestamp", level, category, message, details, session_log_path, session_log_content, credential_username) FROM stdin;
\.


--
-- Data for Name: job_logs; Type: TABLE DATA; Schema: netraven; Owner: netraven
--

COPY netraven.job_logs (id, session_id, job_type, status, start_time, end_time, result_message, job_data, retention_days, device_id, created_by) FROM stdin;
\.


--
-- Data for Name: scheduled_jobs; Type: TABLE DATA; Schema: netraven; Owner: netraven
--

COPY netraven.scheduled_jobs (id, name, device_id, schedule_type, schedule_time, schedule_interval, schedule_day, enabled, created_at, updated_at, last_run, next_run, created_by, job_data) FROM stdin;
\.


--
-- Data for Name: tag_rules; Type: TABLE DATA; Schema: netraven; Owner: netraven
--

COPY netraven.tag_rules (id, name, description, rule_criteria, is_active, created_at, updated_at, tag_id) FROM stdin;
\.


--
-- Data for Name: tags; Type: TABLE DATA; Schema: netraven; Owner: netraven
--

COPY netraven.tags (id, name, description, color, created_at, updated_at) FROM stdin;
tag-default	Default	Default tag for all devices	#6366F1	2025-04-03 17:04:56.287883	2025-04-03 17:04:56.287884
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: netraven; Owner: netraven
--

COPY netraven.users (id, username, email, full_name, password_hash, is_active, is_admin, created_at, updated_at, notification_preferences) FROM stdin;
\.


--
-- Name: admin_settings admin_settings_pkey; Type: CONSTRAINT; Schema: netraven; Owner: netraven
--

ALTER TABLE ONLY netraven.admin_settings
    ADD CONSTRAINT admin_settings_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: netraven; Owner: netraven
--

ALTER TABLE ONLY netraven.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: backups backups_pkey; Type: CONSTRAINT; Schema: netraven; Owner: netraven
--

ALTER TABLE ONLY netraven.backups
    ADD CONSTRAINT backups_pkey PRIMARY KEY (id);


--
-- Name: credential_tags credential_tags_pkey; Type: CONSTRAINT; Schema: netraven; Owner: netraven
--

ALTER TABLE ONLY netraven.credential_tags
    ADD CONSTRAINT credential_tags_pkey PRIMARY KEY (id);


--
-- Name: credentials credentials_pkey; Type: CONSTRAINT; Schema: netraven; Owner: netraven
--

ALTER TABLE ONLY netraven.credentials
    ADD CONSTRAINT credentials_pkey PRIMARY KEY (id);


--
-- Name: device_tags device_tags_pkey; Type: CONSTRAINT; Schema: netraven; Owner: netraven
--

ALTER TABLE ONLY netraven.device_tags
    ADD CONSTRAINT device_tags_pkey PRIMARY KEY (device_id, tag_id);


--
-- Name: devices devices_pkey; Type: CONSTRAINT; Schema: netraven; Owner: netraven
--

ALTER TABLE ONLY netraven.devices
    ADD CONSTRAINT devices_pkey PRIMARY KEY (id);


--
-- Name: job_log_entries job_log_entries_pkey; Type: CONSTRAINT; Schema: netraven; Owner: netraven
--

ALTER TABLE ONLY netraven.job_log_entries
    ADD CONSTRAINT job_log_entries_pkey PRIMARY KEY (id);


--
-- Name: job_logs job_logs_pkey; Type: CONSTRAINT; Schema: netraven; Owner: netraven
--

ALTER TABLE ONLY netraven.job_logs
    ADD CONSTRAINT job_logs_pkey PRIMARY KEY (id);


--
-- Name: scheduled_jobs scheduled_jobs_pkey; Type: CONSTRAINT; Schema: netraven; Owner: netraven
--

ALTER TABLE ONLY netraven.scheduled_jobs
    ADD CONSTRAINT scheduled_jobs_pkey PRIMARY KEY (id);


--
-- Name: tag_rules tag_rules_pkey; Type: CONSTRAINT; Schema: netraven; Owner: netraven
--

ALTER TABLE ONLY netraven.tag_rules
    ADD CONSTRAINT tag_rules_pkey PRIMARY KEY (id);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: netraven; Owner: netraven
--

ALTER TABLE ONLY netraven.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: netraven; Owner: netraven
--

ALTER TABLE ONLY netraven.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_admin_settings_category; Type: INDEX; Schema: netraven; Owner: netraven
--

CREATE INDEX ix_admin_settings_category ON netraven.admin_settings USING btree (category);


--
-- Name: ix_admin_settings_id; Type: INDEX; Schema: netraven; Owner: netraven
--

CREATE INDEX ix_admin_settings_id ON netraven.admin_settings USING btree (id);


--
-- Name: ix_admin_settings_key; Type: INDEX; Schema: netraven; Owner: netraven
--

CREATE UNIQUE INDEX ix_admin_settings_key ON netraven.admin_settings USING btree (key);


--
-- Name: ix_audit_logs_actor_target; Type: INDEX; Schema: netraven; Owner: netraven
--

CREATE INDEX ix_audit_logs_actor_target ON netraven.audit_logs USING btree (actor_id, target_id);


--
-- Name: ix_audit_logs_event_type_name; Type: INDEX; Schema: netraven; Owner: netraven
--

CREATE INDEX ix_audit_logs_event_type_name ON netraven.audit_logs USING btree (event_type, event_name);


--
-- Name: ix_audit_logs_status_created; Type: INDEX; Schema: netraven; Owner: netraven
--

CREATE INDEX ix_audit_logs_status_created ON netraven.audit_logs USING btree (status, created_at);


--
-- Name: ix_backups_created_at; Type: INDEX; Schema: netraven; Owner: netraven
--

CREATE INDEX ix_backups_created_at ON netraven.backups USING btree (created_at);


--
-- Name: ix_backups_id; Type: INDEX; Schema: netraven; Owner: netraven
--

CREATE INDEX ix_backups_id ON netraven.backups USING btree (id);


--
-- Name: ix_backups_status; Type: INDEX; Schema: netraven; Owner: netraven
--

CREATE INDEX ix_backups_status ON netraven.backups USING btree (status);


--
-- Name: ix_credential_tags_id; Type: INDEX; Schema: netraven; Owner: netraven
--

CREATE INDEX ix_credential_tags_id ON netraven.credential_tags USING btree (id);


--
-- Name: ix_credentials_id; Type: INDEX; Schema: netraven; Owner: netraven
--

CREATE INDEX ix_credentials_id ON netraven.credentials USING btree (id);


--
-- Name: ix_credentials_name; Type: INDEX; Schema: netraven; Owner: netraven
--

CREATE INDEX ix_credentials_name ON netraven.credentials USING btree (name);


--
-- Name: ix_devices_device_type; Type: INDEX; Schema: netraven; Owner: netraven
--

CREATE INDEX ix_devices_device_type ON netraven.devices USING btree (device_type);


--
-- Name: ix_devices_hostname; Type: INDEX; Schema: netraven; Owner: netraven
--

CREATE INDEX ix_devices_hostname ON netraven.devices USING btree (hostname);


--
-- Name: ix_devices_id; Type: INDEX; Schema: netraven; Owner: netraven
--

CREATE INDEX ix_devices_id ON netraven.devices USING btree (id);


--
-- Name: ix_devices_ip_address; Type: INDEX; Schema: netraven; Owner: netraven
--

CREATE INDEX ix_devices_ip_address ON netraven.devices USING btree (ip_address);


--
-- Name: ix_job_log_entries_category; Type: INDEX; Schema: netraven; Owner: netraven
--

CREATE INDEX ix_job_log_entries_category ON netraven.job_log_entries USING btree (category);


--
-- Name: ix_job_log_entries_credential_username; Type: INDEX; Schema: netraven; Owner: netraven
--

CREATE INDEX ix_job_log_entries_credential_username ON netraven.job_log_entries USING btree (credential_username);


--
-- Name: ix_job_log_entries_level; Type: INDEX; Schema: netraven; Owner: netraven
--

CREATE INDEX ix_job_log_entries_level ON netraven.job_log_entries USING btree (level);


--
-- Name: ix_job_log_entries_timestamp; Type: INDEX; Schema: netraven; Owner: netraven
--

CREATE INDEX ix_job_log_entries_timestamp ON netraven.job_log_entries USING btree ("timestamp");


--
-- Name: ix_job_logs_job_type; Type: INDEX; Schema: netraven; Owner: netraven
--

CREATE INDEX ix_job_logs_job_type ON netraven.job_logs USING btree (job_type);


--
-- Name: ix_job_logs_session_id; Type: INDEX; Schema: netraven; Owner: netraven
--

CREATE INDEX ix_job_logs_session_id ON netraven.job_logs USING btree (session_id);


--
-- Name: ix_job_logs_start_time; Type: INDEX; Schema: netraven; Owner: netraven
--

CREATE INDEX ix_job_logs_start_time ON netraven.job_logs USING btree (start_time);


--
-- Name: ix_job_logs_status; Type: INDEX; Schema: netraven; Owner: netraven
--

CREATE INDEX ix_job_logs_status ON netraven.job_logs USING btree (status);


--
-- Name: ix_scheduled_jobs_id; Type: INDEX; Schema: netraven; Owner: netraven
--

CREATE INDEX ix_scheduled_jobs_id ON netraven.scheduled_jobs USING btree (id);


--
-- Name: ix_tag_rules_id; Type: INDEX; Schema: netraven; Owner: netraven
--

CREATE INDEX ix_tag_rules_id ON netraven.tag_rules USING btree (id);


--
-- Name: ix_tags_id; Type: INDEX; Schema: netraven; Owner: netraven
--

CREATE INDEX ix_tags_id ON netraven.tags USING btree (id);


--
-- Name: ix_tags_name; Type: INDEX; Schema: netraven; Owner: netraven
--

CREATE UNIQUE INDEX ix_tags_name ON netraven.tags USING btree (name);


--
-- Name: ix_users_email; Type: INDEX; Schema: netraven; Owner: netraven
--

CREATE UNIQUE INDEX ix_users_email ON netraven.users USING btree (email);


--
-- Name: ix_users_id; Type: INDEX; Schema: netraven; Owner: netraven
--

CREATE INDEX ix_users_id ON netraven.users USING btree (id);


--
-- Name: ix_users_username; Type: INDEX; Schema: netraven; Owner: netraven
--

CREATE UNIQUE INDEX ix_users_username ON netraven.users USING btree (username);


--
-- Name: backups backups_device_id_fkey; Type: FK CONSTRAINT; Schema: netraven; Owner: netraven
--

ALTER TABLE ONLY netraven.backups
    ADD CONSTRAINT backups_device_id_fkey FOREIGN KEY (device_id) REFERENCES netraven.devices(id);


--
-- Name: credential_tags credential_tags_credential_id_fkey; Type: FK CONSTRAINT; Schema: netraven; Owner: netraven
--

ALTER TABLE ONLY netraven.credential_tags
    ADD CONSTRAINT credential_tags_credential_id_fkey FOREIGN KEY (credential_id) REFERENCES netraven.credentials(id) ON DELETE CASCADE;


--
-- Name: credential_tags credential_tags_tag_id_fkey; Type: FK CONSTRAINT; Schema: netraven; Owner: netraven
--

ALTER TABLE ONLY netraven.credential_tags
    ADD CONSTRAINT credential_tags_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES netraven.tags(id) ON DELETE CASCADE;


--
-- Name: device_tags device_tags_device_id_fkey; Type: FK CONSTRAINT; Schema: netraven; Owner: netraven
--

ALTER TABLE ONLY netraven.device_tags
    ADD CONSTRAINT device_tags_device_id_fkey FOREIGN KEY (device_id) REFERENCES netraven.devices(id) ON DELETE CASCADE;


--
-- Name: device_tags device_tags_tag_id_fkey; Type: FK CONSTRAINT; Schema: netraven; Owner: netraven
--

ALTER TABLE ONLY netraven.device_tags
    ADD CONSTRAINT device_tags_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES netraven.tags(id) ON DELETE CASCADE;


--
-- Name: devices devices_owner_id_fkey; Type: FK CONSTRAINT; Schema: netraven; Owner: netraven
--

ALTER TABLE ONLY netraven.devices
    ADD CONSTRAINT devices_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES netraven.users(id);


--
-- Name: job_log_entries job_log_entries_job_log_id_fkey; Type: FK CONSTRAINT; Schema: netraven; Owner: netraven
--

ALTER TABLE ONLY netraven.job_log_entries
    ADD CONSTRAINT job_log_entries_job_log_id_fkey FOREIGN KEY (job_log_id) REFERENCES netraven.job_logs(id) ON DELETE CASCADE;


--
-- Name: job_logs job_logs_created_by_fkey; Type: FK CONSTRAINT; Schema: netraven; Owner: netraven
--

ALTER TABLE ONLY netraven.job_logs
    ADD CONSTRAINT job_logs_created_by_fkey FOREIGN KEY (created_by) REFERENCES netraven.users(id);


--
-- Name: job_logs job_logs_device_id_fkey; Type: FK CONSTRAINT; Schema: netraven; Owner: netraven
--

ALTER TABLE ONLY netraven.job_logs
    ADD CONSTRAINT job_logs_device_id_fkey FOREIGN KEY (device_id) REFERENCES netraven.devices(id);


--
-- Name: scheduled_jobs scheduled_jobs_created_by_fkey; Type: FK CONSTRAINT; Schema: netraven; Owner: netraven
--

ALTER TABLE ONLY netraven.scheduled_jobs
    ADD CONSTRAINT scheduled_jobs_created_by_fkey FOREIGN KEY (created_by) REFERENCES netraven.users(id);


--
-- Name: scheduled_jobs scheduled_jobs_device_id_fkey; Type: FK CONSTRAINT; Schema: netraven; Owner: netraven
--

ALTER TABLE ONLY netraven.scheduled_jobs
    ADD CONSTRAINT scheduled_jobs_device_id_fkey FOREIGN KEY (device_id) REFERENCES netraven.devices(id);


--
-- Name: tag_rules tag_rules_tag_id_fkey; Type: FK CONSTRAINT; Schema: netraven; Owner: netraven
--

ALTER TABLE ONLY netraven.tag_rules
    ADD CONSTRAINT tag_rules_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES netraven.tags(id);


--
-- PostgreSQL database dump complete
--

